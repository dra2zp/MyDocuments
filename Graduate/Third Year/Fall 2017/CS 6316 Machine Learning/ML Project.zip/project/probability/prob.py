import pandas as pd
import re
import matplotlib as plt
from nltk.corpus import stopwords
import time

# Read in data
plt.get_backend()
data = pd.read_csv("./twitter-gender.csv",usecols= [0,5,19,17,21,10,11],encoding='latin1')

# Data Cleaning function
def cleaning(s):
    if(isinstance(s, str)):
        s = str(s)
        s = s.lower()
        s = s.replace("&amp;", "")
        s = re.sub('\s\W',' ',s)
        s = re.sub('\W,\s',' ',s)
        s = re.sub(r'[^\w]', ' ', s)
        s = re.sub("\d+", "", s)
        s = re.sub('\s+',' ',s)
        s = re.sub('[!@#$_]', '', s)
        s = s.replace(","," ")
        s = s.replace("[\w*"," ")
        s = s.replace("â","")
        s = s.replace("á", "")
        s = s.replace("å", "")
        s = s.replace("ä", "")
        s = s.replace("ã", "")
        s = s.replace("ê", "")
        s = s.replace("é", "")
        s = s.replace("ï", "")
        s = s.replace("î", "")
        s = s.replace("ì", "")
        s = s.replace("ô", "")
        s = s.replace("ò", "")
        s = s.replace("ö", "")
        s = s.replace("û","")
        s = s.replace("ü","")
        s = s.replace("ù", "")
        s = s.replace("ª", "")
        return s
    else:
        return ""

# how long does preprocessing take?
start = time.time()

#Clean tweets
data['Tweets'] = [cleaning(s) for s in data['text']]

#Clean Description
data['Description'] = [cleaning(s) for s in data['description']]

#Define Stopwords
stop = set(stopwords.words('english'))
stop.add("co")
stop.add("com")
stop.add("http")
stop.add("https")

#Process Tweets
data['Tweets'] = data['Tweets'].str.lower().str.split()
data['Tweets'] = data['Tweets'].apply(lambda x : [item for item in x if item not in stop])

#Process Descriptions
data['Description'] = data['Description'].str.lower().str.split()
data['Description'] = data['Description'].apply(lambda x : [item for item in x if item not in stop])

# function for converting string array into a single string separated by spaces
def convertArrayToString(array):
    string = " "
    for word in array:
        string = string + word + " "
    return string

# 'descString' is the single-string version of 'Description'
# 'tweetString' is the single-string version of 'Tweets'
data['descString'] = [convertArrayToString(wordArray) for wordArray in data['Description']]
data['tweetString'] = [convertArrayToString(wordArray) for wordArray in data['Tweets']]

#Separate by Gender
Male = data[data['gender'] == 'male']
Female = data[data['gender'] == 'female']
Brand = data[data['gender'] == 'brand']

def calc_prob(word, df):
    
    total = df.shape[0]
    subset = df.loc[df['tweetString'].str.contains(word)]
    count = subset.shape[0]
    freq = count / total
    return(freq)

#For each word
words = open("words.txt","r")
delim = ", "

print("Word, Mness, Fness, Bness")
for word in words:

    word = word.replace("\n","")
    word = " " + word + " "
    word = re.sub(' +',' ', word)
    #calculate M_prob, F_prob, B_prob,
    m_prob = calc_prob(word, Male)
    f_prob = calc_prob(word, Female)
    b_prob = calc_prob(word, Brand)
    
    #M_prob - (F_prob + B_prob)/2
    maleness = m_prob - (f_prob + b_prob) / 2
    femaleness = f_prob - (m_prob + b_prob) / 2
    brandness = b_prob - (m_prob + f_prob) / 2
    print(word + delim + str(maleness) + delim + str(femaleness) + delim + str(brandness))
