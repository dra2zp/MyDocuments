import pandas as pd
import re
import matplotlib as plt
from nltk.corpus import stopwords
import time

# Read in data
plt.get_backend()
tweets = pd.read_csv("./twitter-gender-revised.csv",usecols= [0,5,19,17,21,10,11],encoding='latin1')
data = pd.read_csv("./data.csv", encoding='latin1')

# Data Cleaning function
def cleaning(s):
    if(isinstance(s, str)):
        s = str(s)
        s = s.lower()
        s = s.replace("&amp;", "")
        s = re.sub('\s\W',' ',s)
        s = re.sub('\W,\s',' ',s)
        s = re.sub(r'[^\w]', ' ', s)
        s = re.sub("\d+", "", s)
        s = re.sub('\s+',' ',s)
        s = re.sub('[!@#$_]', '', s)
        s = s.replace(","," ")
        s = s.replace("[\w*"," ")
        s = s.replace("â","")
        s = s.replace("á", "")
        s = s.replace("å", "")
        s = s.replace("ä", "")
        s = s.replace("à", "")
        s = s.replace("ã", "")
        s = s.replace("ç", "")
        s = s.replace("ê", "")
        s = s.replace("ë", "")
        s = s.replace("è", "")
        s = s.replace("é", "")
        s = s.replace("ï", "")
        s = s.replace("î", "")
        s = s.replace("í", "")
        s = s.replace("ì", "")
        s = s.replace("ñ", "")
        s = s.replace("ô", "")
        s = s.replace("ò", "")
        s = s.replace("õ", "")
        s = s.replace("ð", "")
        s = s.replace("ø", "")
        s = s.replace("ó", "")
        s = s.replace("ö", "")
        s = s.replace("û","")
        s = s.replace("ü","")
        s = s.replace("µ", "")
        s = s.replace("ù", "")
        s = s.replace("ý", "")
        s = s.replace("ª", "")
        s = s.replace("æ", "")
        s = s.replace("¼", "")
        s = s.replace("¾", "")
        return s
    else:
        return ""
#Clean tweets
tweets['Tweets'] = [cleaning(s) for s in tweets['text']]

#Clean Description
tweets['Description'] = [cleaning(s) for s in tweets['description']]

#Define Stopwords
stop = set(stopwords.words('english'))
stop.add("co")
stop.add("com")
stop.add("http")
stop.add("https")

#Process Tweets
tweets['Tweets'] = tweets['Tweets'].str.lower().str.split()
tweets['Tweets'] = tweets['Tweets'].apply(lambda x : [item for item in x if item not in stop])

word_vals = pd.read_csv("./data.csv",encoding='latin1')

delim = ", "

for tweet in tweets['Tweets']:
    Mness = 0
    Fness = 0
    Bness = 0

    present = pd.Series(tweet).isin(word_vals['Word'])

    for i in range(0, present.shape[0]):
        if present[i]:
            word = tweet[i]
            word_ind = word_vals.index[word_vals['Word'] == word].tolist()[0]
            Mness += word_vals.iloc[word_ind, 1]
            Fness += word_vals.iloc[word_ind, 2]
            Bness += word_vals.iloc[word_ind, 3]

    tweet_str = " ".join(str(e) for e in tweet)
    print(tweet_str + delim + str(Mness) + delim + str(Fness) + delim + str(Bness) + delim)
