from id3 import Id3Estimator
from id3 import export_graphviz
from sklearn import preprocessing
from sklearn.pipeline import Pipeline
from sklearn.metrics import confusion_matrix
import pandas as pd
import numpy as np
import scipy.stats as st

# class to encode multiple columns
class MultiColumnLabelEncoder:
    def __init__(self,columns = None):
        self.columns = columns # array of column names to encode

    def fit(self,X,y=None):
        return self # not relevant here

    # transforms columns of X specified in self.columns using LabelEncoder()
    # if no columns specified, transforms all columns in X
    def transform(self,X):
        output = X.copy()
        if self.columns is not None:
            for col in self.columns:
                output[col] = preprocessing.LabelEncoder().fit_transform(output[col])
        else:
            for colname,col in output.iteritems():
                output[colname] = preprocessing.LabelEncoder().fit_transform(col)
        return output

    def fit_transform(self,X,y=None):
        return self.fit(X,y).transform(X)

# data column names
names = ['fav_number', 'link_colorGroup', 'retweet_count', 'sidebar_colorGroup', 'tweet_count', 'gender']
# read in the data
gender_data = pd.read_csv('genderCSVedit.csv', header=None, names=names)
# wrap in dataframe
gender_df = pd.DataFrame(gender_data)

# create transformed data frame
# insert the names of the columns that must be encoded as strings
transformed = MultiColumnLabelEncoder(
    columns = ['link_colorGroup', 'sidebar_colorGroup', 'gender']).fit_transform(gender_df)

# slice the transformed dataframe into an array
data = np.array(transformed.ix[:, 0:5])
# identify the target
target = np.array(transformed['gender'])

estimator = Id3Estimator()
estimator.fit(data, target)
export_graphviz(estimator.tree_, 'tree.dot', names)

print(confusion_matrix(target, estimator.predict(data)))