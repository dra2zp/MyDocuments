import sys # used for determining the number of command-line parameters and
           # accessing the name of the text file

def traverse(): # the function to print the minimum sum path of the triangle
    if (len(sys.argv) != 2): # if the text file is not given
        print ("Please enter the name of the text file as a command-line parameter.") # print an error message
        return
    triangle = [] # triangle is a 2-D array and will be used to store all of the
                  # numbers in the triangle
    minSumPath = [] # minSumPath is a 2-D array and will be used to store the
                    # sums
    numLines = 0 # numLines will store the number of rows in the triangle (i.e.
                 # the size of the 2-D array)
    with open(sys.argv[1]) as file: # open the text file
        for line in file: # for each line in the file (i.e. row)
            triangle.append([int(n) for n in line.split() if n.isdigit()])
            minSumPath.append([int(n) for n in line.split() if n.isdigit()])
            # create an array of the numbers on that line and append it to both
            # 2-D arrays triangle and minSumPath
            numLines += 1 # increment numLines by one
    i = numLines - 2 # begin at the second-to-last row in the triangle and work
                     # backwards
    while (i >= 0): # while we are still within the bounds of the array
        j = 0 # reset j to zero
        while (j <= i): # while we are still within the bounds of the inner
                        # array
            if (minSumPath[i + 1][j] <= minSumPath[i + 1][j + 1]):
                # if the number's left child is less than or equal to the
                # number's right child
                minSumPath[i][j] += minSumPath[i + 1][j] # add the left child
                                                         # to its parent
            else: # if the number's right child is less than the number's left
                  # child
                minSumPath[i][j] += minSumPath[i + 1][j + 1]
                # add the right child to its parent
            j += 1 # increment j by one
        i -= 1 # decrement i by one
    i = 0 # initialize i to zero
    j = 0 # initialize j to zero
    sum = triangle[i][j] # initialize the sum to the root of the triangle
    print (str(triangle[i][j])) # print the root of the triangle
    while (i < numLines - 1): # while we have not gone past the number of rows
                              # in the triangle
        i += 1 # increment i by one
        if (minSumPath[i][j] <= minSumPath[i][j + 1]):
            # if the sum on the left is less than or equal to the sum on the
            # right
            sum += triangle[i][j] # add the number's left child to the sum
            print (str(triangle[i][j])) # print the number's left child
        else: # if the sum on the right is less than the sum on the left
            j += 1 # increment j by one
            sum += triangle[i][j] # add the number's right child to the sum
            print (str(triangle[i][j])) # print the number's right child
    # print (str(sum)) # print the sum
    return

traverse() # call the traverse function
