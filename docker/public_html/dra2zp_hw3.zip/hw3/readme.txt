D.J. Anderson
dra2zp
05/30/2017
CS 4640
Homework 3

answers.txt -> my answers to "The Post JavaScript Apocalypse" by Douglas Crockford
