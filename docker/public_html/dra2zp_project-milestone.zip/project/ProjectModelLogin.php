<?php
// D.J. Anderson
// dra2zp
// Project
// ProjectModelLogin.php

require_once('/home/dra2zp/.mysqlpass.inc.php');

class Login {
	private static $host = 'localhost';
	private static $user = 'dbuser';
	private static $database = 'project';
	private $connection;
	public function __construct() {
		try {
			$this->connection = new PDO(
				"mysql:host=" . self::$host,
				self::$user,
				MySQLPassword::$password
			);
		}
		catch (PDOException $e) {
			// failure to connect
			throw new Exception("Could not connect: " . $e->getMessage());
		}
		if (!$this->connection->query("USE " . self::$database)) {
			throw new Exception("Could not connect: " . $e->getMessage());
		}
	}
	public function verify($username, $password) {
		$prepared = $this->connection->prepare(
			"SELECT password FROM users WHERE username = :username"
		);
		if (!$prepared->execute([":username" => $username])) {
			// failing to execute the query
			throw new Exception("Fatal Error: Failed to execute the query");
		}
		if ($prepared->rowCount() == 0) {
			// no result
			throw new Exception("User $username not found");
		}
		$row = $prepared->fetch(PDO::FETCH_ASSOC);
		$db_password = $row['password'];
		if (sha1($password) != $db_password) {
			throw new Exception("Password incorrect");
		}
		return true;
	}
}
?>