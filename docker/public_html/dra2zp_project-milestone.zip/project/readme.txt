D.J. Anderson
dra2zp
Project
Milstone
readme.txt

ProjectLogin.php -> login page

Note: Changing the URL to
		.../project/ProjectController.php?request=make
	will create the database. The login page is
		.../project/ProjectLogin.php

mysqldump.sql -> dump of the 'project' database
CreateDB.php -> creates the MySQL database 'project'
uva-rotunda.jpg -> background image for login page
LoginFirewall.php -> credentials are sent here for verifying
ProjectModelLogin.php -> model for communicating with the database in order to verify user login
LoginSuccess.php -> creates $_SESSION to authenticate user, redirects user to main page
ProjectMain.php -> main page for the grade calculator where users can view their classes
ProjectMain.js -> JavaScript for manipulating the main page
home-page.jpg -> background image for main page
ProjectModel.php -> model for communicating with the database in order to perform any functions requiring access to the database
ProjectView.php -> view for communicating with the model and formatting the return
ProjectController.php -> controller for sending incoming requests to the appropriate functions
CreateAccount.php -> web page for creating a new user account
create-account-bg.jpg -> background image for create account page
ProjectCreateClass.php -> web page for creating a new class
ProjectRemoveClass.php -> web page for removing an existing class
ProjectRemoveClass.js -> JavaScript for manipulating the remove class page
ProjectGrades.php -> web page for viewing assignments and grades inside a class
ProjectGrades.js -> JavaScript for manipulating the grades page

Answers:

(1)	I have spent a total of approximately 32 hours so far on this project.
(2)	The most challenging aspect of this assignment is the time constraint. We only have five days to develop a fully functioning website, which is pretty
	difficult. I don't think there's one aspect in particular that's especially challenging. Each aspect takes up a lot of time, and it adds up. It can
	take me up to an hour to fix relatively small bugs (e.g. a missing "+" in some JavaScript code because the error message indicated a need for a closing
	parenthesis).
(3)	Yes, I completed a bit more work than expected for the milestone. I tried to get as much of it completed as I possibly could before Thursday because I
	should probably study at least a little bit for my final exam on Friday.
(4)	There aren't any significant changes to my project, except that I highly doubt that I will be able to implement functionality for the weighted grades
	just because I'm short on time and still have a few more features to add (see below).
(5)	I have just finished fixing the bugs on the grades calculation part of the website. The parts I still must complete are the following:
		- Implement functionality for calculating the minimum grade needed to receive a given percentage in the class
		- Implement a GPA calculator on the main page of the website that shows the user their overall GPA
		- Incorporate a third-party library into the website (e.g. a graph that shows the user a graphical representation of their grades
		- Add more comments to my code to better indicate what everything does
		- Add more validations to form inputs
		- Add more user-friendly error messages