<?php
session_start();

// D.J. Anderson
// dra2zp
// Project
// LoginSuccess.php

if ($_SESSION['loggedIn'] = true) {
	if (!$_SESSION['name']) {
		header('Location:ProjectController.php?request=getName');
	}
	header('Location:ProjectMain.php');
}
else {
	header('Location:ProjectLogin.php');
}
?>