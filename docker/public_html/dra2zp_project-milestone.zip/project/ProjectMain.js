// D.J. Anderson
// dra2zp
// Project
// ProjectMain.js

// wait until the DOM is fully-loaded

// same as
// $(document).ready(handler)

$(function() {
	var request = $.ajax({
		type: "GET",
		url: "ProjectController.php?request=showClasses",
		dataType: "json"
	});
	request.done(function(data) {
		for (var i = 0; i < data.length; i++) {
			$("#classes").append(
				'<li role="presentation"><a href="ProjectGrades.php?class=' + data[i]["title"] + '">' + data[i]["title"] + '</a></li>'
			);
		}
	});
});