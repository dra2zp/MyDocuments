// D.J. Anderson
// dra2zp
// Project
// ProjectRemoveClass.js

// wait until the DOM is fully-loaded

// same as
// $(document).ready(handler)

$(function() {
	var request = $.ajax({
		type: "GET",
		url: "ProjectController.php?request=showClasses",
		dataType: "json"
	});
	request.done(function(data) {
		for (var i = 0; i < data.length; i++) {
			$("#classes").append(
				'<input id="title" name="title" type="radio" value="' + data[i]["title"] + '">' + data[i]["title"] +'</input><br>'
			);
		}
	});
});