// D.J. Anderson
// dra2zp
// Project
// ProjectGrades.js

var points_earned_sum = 0;
var points_possible_sum = 0;
var distribution = [];
var letters = ["F", "D-", "D", "D+", "C-", "C", "C+", "B-", "B", "B+", "A-", "A", "A+"];

function round(value, decimals) {
	return (Number(Math.round(value + 'e' + decimals) + 'e-' + decimals));
}

function get_grade(value) {
	var position = 0;
	if (value >= 1) {
		return "A+";
		position = 14;
	}
	while (position < 14) {
		if (value >= distribution[position]) {
			position++;
		}
		else {
			return letters[position - 1];
			position = 14;
		}
	}
}

function change_color(value) {
	if (value >= distribution[10]) {
		$("body").attr('id', 'green');
	}
	else if (value >= distribution[7]) {
		$("body").attr('id', 'blue');
	}
	else if (value >= distribution[4]) {
		$("body").attr('id', 'yellow');
	}
	else if (value >= distribution[1]) {
		$("body").attr('id', 'orange');
	}
	else if (value >= distribution[0]) {
		$("body").attr('id', 'red');
	}
}

function constructor() {
	
	var parent_node = document.getElementById("grades-body");
	while (parent_node.firstChild) {
		parent_node.removeChild(parent_node.firstChild);
	}
	
	var parent_node = document.getElementById("final-grade-body");
	while (parent_node.firstChild) {
		parent_node.removeChild(parent_node.firstChild);
	}

	var earned = $.ajax({
		type: "GET",
		url: "ProjectController.php?request=pointsEarned",
		dataType: "json"
	});
	earned.done(function(data) {
		for (var i = 0; i < data.length; i++) {
			points_earned_sum += (parseFloat(data[i]["points_earned"]));
		}
	});
	
	var possible = $.ajax({
		type: "POST",
		url: "ProjectController.php?request=pointsPossible",
		dataType: "json"
	});
	possible.done(function(data) {
		for (var i = 0; i < data.length; i++) {
			points_possible_sum += (parseFloat(data[i]["points_possible"]));
		}
	});
	
	var scale = $.ajax({
		type: "GET",
		url: "ProjectController.php?request=gradingScale",
		dataType: "json"
	});
	scale.done(function(data) {
		distribution.push(data[0]["f"]);
		distribution.push(data[0]["d_minus"]);
		distribution.push(data[0]["d"]);
		distribution.push(data[0]["d_plus"]);
		distribution.push(data[0]["c_minus"]);
		distribution.push(data[0]["c"]);
		distribution.push(data[0]["c_plus"]);
		distribution.push(data[0]["b_minus"]);
		distribution.push(data[0]["b"]);
		distribution.push(data[0]["b_plus"]);
		distribution.push(data[0]["a_minus"]);
		distribution.push(data[0]["a"]);
		distribution.push(data[0]["a_plus"]);
	});
	
	var populate = $.ajax({
		type: "GET",
		url: "ProjectController.php?request=showGrades",
		dataType: "json"
	});
	populate.done(function(data) {
		for (var i = 0; i < data.length; i++) {
			var assignment = data[i]["assignment"];
			var points_earned = round(parseFloat(data[i]["points_earned"]), 2);
			var points_possible = round(parseFloat(data[i]["points_possible"]), 2);
			var score = round(points_earned, 2) / round(points_possible, 2);
			var decimal = round(score * 100, 2);
			var percentage = decimal +"%";
			var grade = get_grade(score);
			$("#grades-body").append(
				'<tr><td class="' + assignment + '">' + assignment + '</td><td class="' + points_earned + '">' + points_earned +
				'</td><td class="' + points_possible + '">' + points_possible + '</td><td>' + percentage +
				'</td><td>' + grade + '</td><td><span class="glyphicon glyphicon-remove grade-remove"></span>' + '</td></tr>'
			);
		}
	});

	if (points_possible_sum == 0) {
		var final_percentage = "**";
		var final_grade = "**";
	}
	else {
		var final_score = round(points_earned_sum, 2) / round(points_possible_sum, 2);
		var final_decimal = round(final_score * 100, 2);
		var final_percentage = final_decimal + "%";
		var final_grade = get_grade(final_score);
		change_color(final_score);
	}
	
	$("#final-grade-body").append(
		'<tr><td>' + final_percentage + '</td><td>' + final_grade + '</td></tr>'
	);
	
	points_earned_sum = 0;
	points_possible_sum = 0;
}

$(function() {

	constructor();
	
	$("#add").click(function(evt) {
	
		evt.preventDefault();
		
		var assignment_name = $("#assignment-name").val();
		var points_earned = $("#points-earned").val();
		var points_possible = $("#points-possible").val();
		if (assignment_name.length == 0 || assignment_name.length > 40) {
			alert("Assignment Name must be between 1 and 40 characters");
			return;
		}
		if (isNaN(parseFloat(points_earned)) || points_earned.length == 0) {
			alert("Points Earned must be a number");
			return;
		}
		if (isNaN(parseFloat(points_possible)) || points_possible.length == 0) {
			alert("Points Possible must be a number");
			return;
		}
		
		var addGrade = $.ajax({
			type: "POST",
			url: "ProjectController.php?request=newGrade",
			data: {category: "NULL", weight: "NULL", assignment: assignment_name, points_earned: points_earned, points_possible: points_possible}
		});
		addGrade.done(function(data) {
			constructor();
		});
		
		$("#assignment-name").val("");
		$("#points-earned").val("");
		$("#points-possible").val("");
		
		setTimeout(function() {
			document.getElementById("invisible").click();
		}, 500);
	});
	
	$("#grades").on("click", "table .grade-remove", function(evt) {
	
		evt.preventDefault();
		
		$(evt.target).parent().parent().attr('id', 'remove');
		$("#remove > :nth-child(1)").attr('id', 'get_assignment');
		$("#remove > :nth-child(2)").attr('id', 'get_points_earned');
		$("#remove > :nth-child(3)").attr('id', 'get_points_possible');
		var removeAssignment = $("#get_assignment").attr('class');
		var removePointsEarned = $("#get_points_earned").attr('class');
		var removePointsPossible = $("#get_points_possible").attr('class');
		points_earned_sum -= (parseFloat(removePointsEarned));
		points_possible_sum -= (parseFloat(removePointsPossible));
		
		var removeGrade = $.ajax({
			type: "POST",
			url: "ProjectController.php?request=deleteGrade",
			data: {assignment: removeAssignment}
		});
		removeGrade.done(function(data) {
			constructor();
		});
		
		setTimeout(function() {
			document.getElementById("invisible").click();
		}, 500);
	});
	
	$("#calculate").click(function(evt) {
	
		evt.preventDefault();
		
		$("#goal").append(
			'<label class="control-label" for="goal-grade">Goal Percentage</label><input type="text" name="goal-grade" class="form-control"</input><button class="btn bton-submit" id="calc-min">Calculate!</button>'
		);
	});
	
	$("#calc-min").click(function(evt) {
		
		evt.preventDefault();
		
		var goal_earned = 0;
		var goal_possible = 0;
		
		var earned = $.ajax({
			type: "GET",
			url: "ProjectController.php?request=pointsEarned",
			dataType: "json"
		});
		earned.done(function(data) {
			for (var i = 0; i < data.length; i++) {
				goal_earned += (parseFloat(data[i]["points_earned"]));
			}
		});
	
		var possible = $.ajax({
			type: "POST",
			url: "ProjectController.php?request=pointsPossible",
			dataType: "json"
		});
		possible.done(function(data) {
			for (var i = 0; i < data.length; i++) {
				goal_possible += (parseFloat(data[i]["points_possible"]));
			}
		});
		
		var points_possible = $("#points-possible").val();
		var goal = parseFloat($("#goal-grade").val());
		var total_possible = goal_possible + points_possible;
		var min = round(((goal / 100) * total_possible) * 100, 2);
		
		$("#output").append(
			'<h1>You need ' + min + '% in order to have a ' + goal + '% in the class.</h1>'
		);
	});
	
	$("#invisible").click(function(evt) {
		
		evt.preventDefault();
		
		constructor();
	});
	
	setTimeout(function() {
		document.getElementById("invisible").click();
    }, 100);
});