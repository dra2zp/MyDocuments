<?php
session_start();
// D.J. Anderson
// dra2zp
// Project
// LoginFirewall.php

require_once('ProjectModelLogin.php');
if(isset($_POST['cmd']) && $_POST['cmd'] == 'login') {
	$username = $_POST['username'];
	$password = $_POST['password'];
	// verify that the username and password are correct
	$model = new Login();
	try {
		$login = $model->verify($username, $password);
		$_SESSION['loggedIn'] = true;
		$_SESSION['username'] = $username;
		header('Location:LoginSuccess.php');
	}
	catch (Exception $e) {
		// redirect the user
		echo "Login failed.\n" . $e->getMessage();
		echo ".\nPlease return to the previous page and try logging in again or create an account.";
	}
}
else {
	header('Location:ProjectLogin.php');
}
?>