<?php
// D.J. Anderson
// dra2zp
// Project
// ProjectView.php

// view class

require_once('ProjectModel.php');
require_once('CreateDB.php');

class ProjectView {
	private $model;
	private $create;
	function __construct() {
		$this->model = new ProjectModel();
		$this->create = new CreateDB();
	}
	public function make() {
		$result = $this->create->LoadDB();
	}
	public function setName($username) {
		$result = $this->model->getName($username);
		$_SESSION['name'] = $result;
	}
	public function newUser($first, $last, $username, $password) {
		$result = $this->model->createAccount($first, $last, $username, $password);
		header('Location:ProjectLogin.php');
	}
	public function showClasses($username) {
		$result = $this->model->getClasses($username);
		echo json_encode($result);
	}
	public function newClass($username, $title, $credits, $a_plus, $a, $a_minus, $b_plus, $b, $b_minus, $c_plus, $c, $c_minus, $d_plus, $d, $d_minus, $f,
		$system, $category1, $weight1, $category2, $weight2, $category3, $weight3, $category4, $weight4, $category5, $weight5,
		$category6, $weight6, $category7, $weight7, $category8, $weight8, $category9, $weight9, $category10, $weight10) {
		$result = $this->model->createClass($username, $title, $credits,
		$a_plus, $a, $a_minus, $b_plus, $b, $b_minus, $c_plus, $c, $c_minus, $d_plus, $d, $d_minus, $f,
		$system, $category1, $weight1, $category2, $weight2, $category3, $weight3, $category4, $weight4, $category5, $weight5,
		$category6, $weight6, $category7, $weight7, $category8, $weight8, $category9, $weight9, $category10, $weight10);
	}
	public function deleteClass($username, $title) {
		$result = $this->model->removeClass($username, $title);
	}
	public function showGrades($username, $title) {
		$result = $this->model->getGrades($username, $title);
		echo json_encode($result);
	}
	public function newGrade($username, $title, $category, $weight, $assignment, $points_earned, $points_possible) {
		$result = $this->model->createGrade($username, $title, $category, $weight, $assignment, $points_earned, $points_possible);
	}
	public function deleteGrade($username, $title, $assignment) {
		$result = $this->model->removeGrade($username, $title, $assignment);
	}
	public function showPointsEarned($username, $title) {
		$result = $this->model->getPointsEarned($username, $title);
		echo json_encode($result);
	}
	public function showPointsPossible($username, $title) {
		$result = $this->model->getPointsPossible($username, $title);
		echo json_encode($result);
	}
	public function showGradingScale($username, $title) {
		$result = $this->model->getGradingScale($username, $title);
		echo json_encode($result);
	}
}
?>