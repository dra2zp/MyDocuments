D.J. Anderson
dra2zp
CS 4640
Homework 1

part1.png -> screenshot for part 1

part2.html -> main page for part 2
requires "dj.jpg" and "uva.png"

part3.html -> main page for part 3
requires "dj.jpg", "uva.png", "Resume.pdf", "objective.html", "education.html", "uva.pdf", "lfcc.pdf", "jwhs.pdf",
"experience.html", and "skills.html"
